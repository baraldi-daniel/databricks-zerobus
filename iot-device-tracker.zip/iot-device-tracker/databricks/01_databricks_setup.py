# Databricks notebook source
# MAGIC %md
# MAGIC # IoT Device Tracker — Databricks Setup
# MAGIC
# MAGIC Creates the full pipeline infra: `IoT device -> Zerobus -> Delta -> React App`.
# MAGIC
# MAGIC ## ⚠️ How to use this notebook (DO read this first)
# MAGIC
# MAGIC **First-time setup:** fill the widgets above, then click **▶ Run all**. End-to-end takes ~5 min.
# MAGIC
# MAGIC **Re-running:** the notebook is idempotent. Just click **Run all** again — every cell knows how to skip work that's already done.
# MAGIC
# MAGIC **Rotate the device's OAuth secret:** set widget **`rotate_secret = true`** and run again. A fresh `device_config.json` will be printed in cell 9.
# MAGIC
# MAGIC **Re-deploy ONLY the app** (e.g. after a frontend change): run only cell 8.
# MAGIC
# MAGIC ## What each cell does
# MAGIC
# MAGIC | Cell | Title | What it does | Idempotent? |
# MAGIC |------|-------|--------------|-------------|
# MAGIC | 1 | (this markdown) | Reading material — nothing to run | — |
# MAGIC | 2 | `%pip install` | Installs `databricks-sdk` and restarts Python | ✅ |
# MAGIC | 3 | Config widgets | Reads catalog/schema/table/SP/device_id/app_name/zerobus_endpoint | ✅ |
# MAGIC | 4 | Catalog / Schema / Table | Validates catalog exists, creates schema+table if missing | ✅ — never creates a catalog |
# MAGIC | 5 | Service principal + OAuth secret | Creates the device SP if missing; rotates the secret only when widget says so | ✅ |
# MAGIC | 6 | Build Zerobus endpoint | Constructs `https://<workspace_id>.zerobus.<region>.<cloud>` from the workspace URL + region widget | ✅ |
# MAGIC | 7 | Pick warehouse | Finds a serverless warehouse and grants the device SP `CAN_USE` | ✅ |
# MAGIC | 8 | **Deploy the Databricks App** | Locates `../app/` in the workspace, renders `app.yaml`, creates/updates the app, grants the app SP `USE_CATALOG`/`USE_SCHEMA`/`SELECT` | ✅ |
# MAGIC | 9 | Output 1 — `device_config.json` | Prints the JSON that goes into the device or simulator | — |
# MAGIC | 10 | Summary | Prints table, workspace, SP and App URL | — |
# MAGIC
# MAGIC ## What this notebook will **never** do
# MAGIC
# MAGIC - Create a catalog automatically (storage-root decision is left to a workspace admin). If your catalog doesn't exist, cell 4 fails fast with the exact SQL to run.
# MAGIC - Rotate the OAuth secret unless you ask for it via the `rotate_secret` widget.
# MAGIC - Overwrite existing grants in a destructive way (uses additive PATCH endpoints).
# MAGIC
# MAGIC The dashboard is NOT AI/BI — it lives inside the React app (map + charts).
# MAGIC All names are parameterized via the widgets below.

# COMMAND ----------

# MAGIC %pip install --quiet databricks-sdk>=0.85.0
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Config widgets
dbutils.widgets.text("catalog", "main", "1. Catalog")
dbutils.widgets.text("schema", "iot", "2. Schema")
dbutils.widgets.text("table", "events", "3. Table")
dbutils.widgets.text("sp_display_name", "iot-zerobus-sp", "4. Service Principal name")
dbutils.widgets.text("device_id", "device-01", "5. Default device ID")
dbutils.widgets.dropdown("rotate_secret", "false", ["false", "true"], "7. Rotate OAuth secret?")
dbutils.widgets.text("app_name", "iot-tracker", "8. App name")
dbutils.widgets.dropdown("deploy_app", "true", ["true", "false"], "9. Deploy the Databricks App?")
dbutils.widgets.dropdown(
    "zerobus_region",
    "us-east4",
    [
        # GCP
        "us-central1", "us-east1", "us-east4", "us-west1",
        "europe-west1", "europe-west3", "asia-southeast1",
        # AWS
        "us-east-1", "us-east-2", "us-west-2",
        "eu-west-1", "eu-central-1",
        "ap-southeast-1", "ap-southeast-2",
        # Azure
        "eastus", "eastus2", "westus2",
        "westeurope", "northeurope",
        "southeastasia", "australiaeast",
    ],
    "6. Zerobus region (matches your workspace region)",
)

CATALOG = dbutils.widgets.get("catalog").strip()
SCHEMA = dbutils.widgets.get("schema").strip()
TABLE = dbutils.widgets.get("table").strip()
SP_DISPLAY_NAME = dbutils.widgets.get("sp_display_name").strip()
DEVICE_ID = dbutils.widgets.get("device_id").strip()
ZEROBUS_REGION = dbutils.widgets.get("zerobus_region").strip()

FQN = f"`{CATALOG}`.`{SCHEMA}`.`{TABLE}`"
print(f"Target table: {FQN}")
print(f"Service principal: {SP_DISPLAY_NAME}")

# COMMAND ----------

# DBTITLE 1,Catalog / Schema / Table (idempotent — never creates catalogs)
# We do NOT create catalogs automatically. Catalog creation depends on the
# metastore's storage root or on explicit MANAGED LOCATION, which is a
# workspace-admin decision. This cell validates the catalog exists, then
# creates the schema and table if they don't exist yet. Re-running it is safe.

from databricks.sdk import WorkspaceClient as _WC
_w_pre = _WC()

existing_catalogs = [c.name for c in _w_pre.catalogs.list()]
if CATALOG not in existing_catalogs:
    raise RuntimeError(
        f"Catalog '{CATALOG}' does not exist in this workspace.\n"
        f"Available catalogs: {', '.join(existing_catalogs) or '(none)'}.\n\n"
        f"Create it once (admin action) via either:\n"
        f"  - Catalog Explorer UI -> Create catalog (uses Default Storage), or\n"
        f"  - SQL: CREATE CATALOG `{CATALOG}` MANAGED LOCATION '<your-location>'\n"
        f"Then re-run this notebook — no other changes needed."
    )
print(f"Catalog '{CATALOG}' exists.")

# Schema and table inherit storage from the catalog — safe to create here.
spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{CATALOG}`.`{SCHEMA}`")
print(f"Schema {CATALOG}.{SCHEMA} ready.")

# Detect a pre-existing table to avoid surprises (column drift, etc.)
table_exists = spark.catalog.tableExists(f"{CATALOG}.{SCHEMA}.{TABLE}")
spark.sql(f"""
CREATE TABLE IF NOT EXISTS {FQN} (
  device_id STRING,
  session_id STRING,
  event_timestamp TIMESTAMP,

  latitude DOUBLE,
  longitude DOUBLE,
  altitude DOUBLE,
  speed DOUBLE,
  bearing DOUBLE,
  location_accuracy DOUBLE,
  location_provider STRING,

  accel_x DOUBLE,
  accel_y DOUBLE,
  accel_z DOUBLE,
  accel_magnitude DOUBLE,

  gyro_x DOUBLE,
  gyro_y DOUBLE,
  gyro_z DOUBLE,

  orient_azimuth DOUBLE,
  orient_pitch DOUBLE,
  orient_roll DOUBLE,

  battery_level DOUBLE,
  battery_status STRING,
  battery_temperature DOUBLE,
  is_charging BOOLEAN
)
USING DELTA
CLUSTER BY (device_id, event_timestamp)
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true'
)
""")
if table_exists:
    print(f"Table {FQN} already existed — left as-is (CREATE IF NOT EXISTS is idempotent).")
else:
    print(f"Table {FQN} created.")

# COMMAND ----------

# DBTITLE 1,Service principal + OAuth secret (idempotent)
import time
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
sp_was_new = False

existing = [sp for sp in w.service_principals.list(filter=f'displayName eq "{SP_DISPLAY_NAME}"')]
if existing:
    sp = existing[0]
    print(f"Reusing service principal: {sp.application_id}")
else:
    sp = w.service_principals.create(display_name=SP_DISPLAY_NAME, active=True)
    sp_was_new = True
    print(f"Created service principal: {sp.application_id}")

SP_APP_ID = sp.application_id
SP_ID = sp.id

# Create a fresh OAuth secret only when:
#   - the SP was just created (so we don't yet have a usable secret), OR
#   - the user explicitly opted in to rotate via the widget.
# Otherwise we leave the existing secret(s) intact and skip emitting credentials.
ROTATE = dbutils.widgets.get("rotate_secret").strip().lower() == "true"

# The SP OAuth secrets API moved around between SDK versions
# (service_principal_secrets / service_principal_secrets_proxy / not exposed).
# Probe for whichever the installed SDK has; if none, fall back to the REST API
# the SDK is built on top of so this notebook keeps working across versions.
def _sp_secrets_api(client):
    for attr in ("service_principal_secrets", "service_principal_secrets_proxy"):
        api = getattr(client, attr, None)
        if api is not None and hasattr(api, "create"):
            return api
    return None


def _create_sp_secret(client, sp_id: int) -> str:
    api = _sp_secrets_api(client)
    if api is not None:
        return api.create(service_principal_id=sp_id).secret
    # REST fallback — works on any SDK that exposes api_client.do
    resp = client.api_client.do(
        "POST",
        f"/api/2.0/accounts/servicePrincipals/{sp_id}/credentials/secrets",
    )
    secret_val = resp.get("secret") or resp.get("client_secret")
    if not secret_val:
        raise RuntimeError(
            "Could not extract secret from REST response — generate it manually "
            "via Workspace Settings -> Identity -> Service principals -> "
            f"{SP_DISPLAY_NAME} -> Generate secret."
        )
    return secret_val


def _list_sp_secrets(client, sp_id: int):
    api = _sp_secrets_api(client)
    if api is not None and hasattr(api, "list"):
        try:
            return list(api.list(service_principal_id=sp_id))
        except Exception:
            pass
    try:
        resp = client.api_client.do(
            "GET",
            f"/api/2.0/accounts/servicePrincipals/{sp_id}/credentials/secrets",
        )
        return resp.get("secrets", []) if isinstance(resp, dict) else []
    except Exception:
        return []


SP_SECRET = None
if sp_was_new or ROTATE:
    SP_SECRET = _create_sp_secret(w, int(SP_ID))
    print("OAuth secret created — captured for output below.")
else:
    existing_secrets = _list_sp_secrets(w, int(SP_ID))
    print(
        f"SP already had {len(existing_secrets)} OAuth secret(s). Not rotating. "
        f"Set widget 'rotate_secret=true' if you need a fresh value."
    )

# Grants are idempotent on Databricks — re-applying produces no error.
spark.sql(f"GRANT USE_CATALOG ON CATALOG `{CATALOG}` TO `{SP_APP_ID}`")
spark.sql(f"GRANT USE_SCHEMA ON SCHEMA `{CATALOG}`.`{SCHEMA}` TO `{SP_APP_ID}`")
spark.sql(f"GRANT MODIFY, SELECT ON TABLE {FQN} TO `{SP_APP_ID}`")
print("Grants ensured (USE_CATALOG, USE_SCHEMA, MODIFY, SELECT).")

# COMMAND ----------

# DBTITLE 1,Build the Zerobus endpoint from workspace ID + region
# Per the official docs, Zerobus endpoints are PER-WORKSPACE:
#   https://<workspace_id>.zerobus.<region>.<cloud-suffix>
# The cloud suffix is inferred from the workspace hostname.
import urllib.parse, re

ws_url = w.config.host
host = urllib.parse.urlparse(ws_url).hostname or ""

# Extract workspace ID from the workspace hostname.
# AWS:   dbc-abcdef-1234.cloud.databricks.com  -> dbc-abcdef-1234
# Azure: adb-<id>.<n>.azuredatabricks.net      -> <id>
# GCP:   <id>.<n>.gcp.databricks.com           -> <id>
m = re.match(r"^([^.]+)\.", host)
workspace_id = m.group(1) if m else ""
# Strip Azure's adb- prefix
workspace_id_clean = workspace_id[4:] if workspace_id.startswith("adb-") else workspace_id

if ".gcp.databricks.com" in host:
    cloud_suffix = "gcp.databricks.com"
elif ".azuredatabricks.net" in host:
    cloud_suffix = "azuredatabricks.net"
else:
    cloud_suffix = "cloud.databricks.com"

zerobus_endpoint = f"https://{workspace_id_clean}.zerobus.{ZEROBUS_REGION}.{cloud_suffix}"

print(f"Workspace host  : {host}")
print(f"Workspace id    : {workspace_id_clean}")
print(f"Region          : {ZEROBUS_REGION}")
print(f"Zerobus endpoint: {zerobus_endpoint}")
print()
print("If ingestion fails with DNS / connection errors, double-check the region")
print("matches your workspace region. Look up the region in:")
print("  UI Databricks -> avatar (top right) -> Workspace details -> Region")

# COMMAND ----------

# DBTITLE 1,Pick a serverless SQL warehouse for the app
warehouses = list(w.warehouses.list())
serverless = [x for x in warehouses if getattr(x, "enable_serverless_compute", False)]
chosen_wh = (serverless or warehouses)[0]
WAREHOUSE_ID = chosen_wh.id
print(f"Warehouse for app: {chosen_wh.name} ({WAREHOUSE_ID})")

try:
    # update_permissions ADDS to existing ACL (idempotent + non-destructive);
    # set_permissions would REPLACE the full ACL and could remove other users.
    w.warehouses.update_permissions(
        warehouse_id=WAREHOUSE_ID,
        access_control_list=[{"service_principal_name": SP_APP_ID, "permission_level": "CAN_USE"}],
    )
    print("SP ensured CAN_USE on warehouse.")
except Exception as e:
    print(f"Warehouse grant skipped: {e}")

# COMMAND ----------

# DBTITLE 1,Deploy the Databricks App (idempotent)
# The app is single-file React via CDN served by FastAPI — no npm build step,
# so the notebook can deploy it directly from sources sitting next to itself in
# the workspace. We look for the `app/` folder relative to this notebook's path.

APP_NAME = dbutils.widgets.get("app_name").strip()
DEPLOY_APP = dbutils.widgets.get("deploy_app").strip().lower() == "true"

def _notebook_dir() -> str:
    ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
    p = ctx.notebookPath().get()
    return p.rsplit("/", 1)[0]


def _find_app_dir(nb_dir: str) -> str | None:
    """Look for an `app/` folder either as a sibling of the notebook or
    one level up (project root). Returns the workspace path or None."""
    candidates = [
        f"{nb_dir}/app",
        f"{nb_dir}/../app",
        f"{nb_dir.rsplit('/', 1)[0]}/app",
    ]
    for c in candidates:
        # Normalize the .. segment
        parts = []
        for seg in c.split("/"):
            if seg == "..":
                if parts and parts[-1] != "":
                    parts.pop()
            else:
                parts.append(seg)
        normalized = "/".join(parts)
        try:
            entries = list(w.workspace.list(normalized))
            names = {e.path.rsplit("/", 1)[-1] for e in entries}
            if "main.py" in names and "static" in names:
                return normalized
        except Exception:
            continue
    return None


def _write_app_yaml(target_dir: str, catalog: str, schema: str, table: str,
                    device_id: str, warehouse_id: str) -> None:
    from databricks.sdk.service.workspace import ImportFormat
    yaml_body = f"""command:
  - "uvicorn"
  - "main:app"
  - "--host"
  - "0.0.0.0"
  - "--port"
  - "8000"

env:
  - name: IOT_CATALOG
    value: "{catalog}"
  - name: IOT_SCHEMA
    value: "{schema}"
  - name: IOT_TABLE
    value: "{table}"
  - name: IOT_DEVICE_ID
    value: "{device_id}"
  - name: IOT_WAREHOUSE_ID
    value: "{warehouse_id}"

resources:
  - name: iot_warehouse
    description: "SQL warehouse that backs the dashboard queries"
    sql_warehouse:
      id: "{warehouse_id}"
      permission: "CAN_USE"
"""
    import base64
    w.workspace.import_(
        path=f"{target_dir}/app.yaml",
        format=ImportFormat.AUTO,
        overwrite=True,
        content=base64.b64encode(yaml_body.encode("utf-8")).decode("ascii"),
    )


if not DEPLOY_APP:
    print("Skipping app deploy (widget deploy_app=false).")
    app_url = None
else:
    nb_dir = _notebook_dir()
    print(f"Notebook directory: {nb_dir}")

    app_src = _find_app_dir(nb_dir)
    if app_src is None:
        print("\n" + "!" * 70)
        print("App source not found in the workspace.")
        print("Upload the 'app/' folder so it sits next to this notebook, or one")
        print("level above. Easiest path: Workspace -> Add -> Git folder, point at")
        print("the iot-device-tracker repo, and re-run this cell.")
        print("Expected to contain: main.py, requirements.txt, static/index.html")
        print("!" * 70)
        app_url = None
    else:
        print(f"App source found: {app_src}")

        # Render the deployment-time app.yaml inside the source folder
        _write_app_yaml(app_src, CATALOG, SCHEMA, TABLE, DEVICE_ID, WAREHOUSE_ID)
        print("Wrote app.yaml with deployment env vars.")

        # Create/deploy the app via REST so we don't depend on a specific
        # databricks-sdk version exposing `databricks.sdk.service.apps`.
        import time as _t

        def _app_get(name):
            try:
                return w.api_client.do("GET", f"/api/2.0/apps/{name}")
            except Exception:
                return None

        def _app_state(info):
            if not isinstance(info, dict):
                return "UNKNOWN"
            return (
                (info.get("compute_status") or {}).get("state")
                or (info.get("status") or {}).get("state")
                or info.get("app_status", {}).get("state")
                or "UNKNOWN"
            )

        def _wait_active(name, timeout_min=20):
            deadline = _t.time() + timeout_min * 60
            last_state = None
            while _t.time() < deadline:
                info = _app_get(name)
                state = _app_state(info)
                if state != last_state:
                    print(f"  app state: {state}")
                    last_state = state
                if state in ("ACTIVE", "RUNNING"):
                    return info
                if state in ("ERROR", "FAILED", "STOPPED"):
                    raise RuntimeError(f"App {name} entered terminal state {state}: {info}")
                _t.sleep(8)
            raise TimeoutError(f"App {name} did not become ACTIVE within {timeout_min} min")

        existing_app = _app_get(APP_NAME)
        if existing_app:
            print(f"Reusing app: {APP_NAME}")
        else:
            print(f"Creating app: {APP_NAME}")
            w.api_client.do("POST", "/api/2.0/apps", body={"name": APP_NAME})
            existing_app = _wait_active(APP_NAME, timeout_min=20)
            print("App created.")

        # The deploy API requires a fully-qualified workspace path beginning
        # with /Workspace/...  Our discovery returns /Users/<email>/... so we
        # prepend the prefix here.
        deploy_path = app_src if app_src.startswith("/Workspace/") else f"/Workspace{app_src}"
        print(f"Starting deployment from {deploy_path} ...")
        deploy_resp = w.api_client.do(
            "POST",
            f"/api/2.0/apps/{APP_NAME}/deployments",
            body={"source_code_path": deploy_path},
        )
        deployment_id = (
            deploy_resp.get("deployment_id")
            or deploy_resp.get("id")
            or (deploy_resp.get("status") or {}).get("deployment_id")
        )
        print(f"Deployment id: {deployment_id}")

        # Poll deployment status
        if deployment_id:
            deploy_deadline = _t.time() + 30 * 60
            last_state = None
            while _t.time() < deploy_deadline:
                dep = w.api_client.do(
                    "GET",
                    f"/api/2.0/apps/{APP_NAME}/deployments/{deployment_id}",
                )
                state = (dep.get("status") or {}).get("state") or "UNKNOWN"
                if state != last_state:
                    print(f"  deployment state: {state}")
                    last_state = state
                if state in ("SUCCEEDED", "FAILED", "STOPPED"):
                    break
                _t.sleep(8)

        app_info = _app_get(APP_NAME) or {}
        app_url = app_info.get("url")
        print(f"\nApp URL: {app_url}")

        # Find every plausible service-principal identifier anywhere in the
        # app metadata. Field names differ between API versions / clouds, so
        # we walk the whole response, then filter to actual UUID-shaped
        # client_ids (display names have spaces and would fail with
        # PRINCIPAL_DOES_NOT_EXIST).
        import re
        UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

        def _find_app_sps(obj, path=""):
            found = []
            if isinstance(obj, dict):
                for k, v in obj.items():
                    found.extend(_find_app_sps(v, f"{path}.{k}"))
            elif isinstance(obj, list):
                for i, v in enumerate(obj):
                    found.extend(_find_app_sps(v, f"{path}[{i}]"))
            elif isinstance(obj, str):
                pl = path.lower()
                # Only accept UUID-shaped values at *principal-like* paths.
                if "principal" in pl and UUID_RE.match(obj):
                    found.append((path, obj))
            return found

        sp_candidates = _find_app_sps(app_info)
        seen = set()
        sp_values = []
        for path, val in sp_candidates:
            if val not in seen:
                seen.add(val)
                sp_values.append(val)
                print(f"  candidate SP from {path}: {val}")

        granted_any = False
        for sp in sp_values:
            try:
                spark.sql(f"GRANT USE_CATALOG ON CATALOG `{CATALOG}` TO `{sp}`")
                spark.sql(f"GRANT USE_SCHEMA ON SCHEMA `{CATALOG}`.`{SCHEMA}` TO `{sp}`")
                spark.sql(f"GRANT SELECT ON TABLE {FQN} TO `{sp}`")
                # Warehouse CAN_USE is normally provisioned automatically by
                # the app's `resources` binding in app.yaml. We try a REST
                # PATCH just in case, but it's optional.
                try:
                    w.api_client.do(
                        "PATCH",
                        f"/api/2.0/permissions/warehouses/{WAREHOUSE_ID}",
                        body={
                            "access_control_list": [
                                {"service_principal_name": str(sp),
                                 "permission_level": "CAN_USE"}
                            ]
                        },
                    )
                except Exception:
                    pass  # app.yaml binding already covers this
                print(f"  ✓ granted USE_CATALOG / USE_SCHEMA / SELECT to {sp}")
                granted_any = True
            except Exception as e:
                print(f"  ✗ grant failed for {sp}: {e}")

        if not granted_any:
            print("\n!! Could NOT auto-grant the app SP. Open the app in the UI,")
            print("   copy the service principal client_id, and grant manually:")
            print(f"   GRANT USE_CATALOG ON CATALOG `{CATALOG}` TO `<sp>`;")
            print(f"   GRANT USE_SCHEMA ON SCHEMA `{CATALOG}`.`{SCHEMA}` TO `<sp>`;")
            print(f"   GRANT SELECT ON TABLE {FQN} TO `<sp>`;")

# COMMAND ----------

# DBTITLE 1,Output 1 — device_config.json (paste into the device or the simulator)
import json

if SP_SECRET is None:
    print("\n" + "=" * 70)
    print("DEVICE CONFIG — secret was NOT rotated this run.")
    print("Use the device_config.json you saved on a previous run.")
    print("To regenerate, set widget 'rotate_secret=true' and re-run this cell.")
    print("=" * 70)
else:
    device_config = {
        "workspace_url": ws_url,
        "zerobus_endpoint": zerobus_endpoint,
        "table_fqn": f"{CATALOG}.{SCHEMA}.{TABLE}",
        "client_id": SP_APP_ID,
        "client_secret": SP_SECRET,
        "device_id": DEVICE_ID,
        "session_id": f"session-{int(time.time())}",
        # ingestion tuning
        "send_interval_seconds": 1.0,
        "batch_size": 1,
    }

    print("\n" + "=" * 70)
    print("DEVICE — copy this JSON to iot_device/device_config.json")
    print("        (or simulator/device_config.json for the load test)")
    print("=" * 70)
    print(json.dumps(device_config, indent=2))
    print("=" * 70)

# COMMAND ----------

# DBTITLE 1,Summary
print("=" * 70)
print(f"Table           : {CATALOG}.{SCHEMA}.{TABLE}")
print(f"Workspace       : {ws_url}")
print(f"Service Principal: {SP_APP_ID}")
print(f"Zerobus endpoint: {zerobus_endpoint}")
if 'app_url' in dir() and app_url:
    print(f"App URL         : {app_url}")
print("=" * 70)
