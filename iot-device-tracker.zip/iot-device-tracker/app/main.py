"""FastAPI backend for the IoT Device Tracker app.

Serves:
- /api/latest               — most recent reading
- /api/events?minutes=N     — events from the last N minutes (default 10)
- /api/stats?minutes=N      — aggregate stats (counts, avg speed, distance)
- /                          — static React frontend (built into ./frontend/dist)
"""
from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from databricks import sql
from databricks.sdk.core import Config
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("app")

CATALOG = os.environ.get("IOT_CATALOG", "main")
SCHEMA = os.environ.get("IOT_SCHEMA", "iot")
TABLE = os.environ.get("IOT_TABLE", "events")
WAREHOUSE_ID = os.environ.get("IOT_WAREHOUSE_ID")
DEVICE_ID = os.environ.get("IOT_DEVICE_ID", "")

FQN = f"`{CATALOG}`.`{SCHEMA}`.`{TABLE}`"

if not WAREHOUSE_ID:
    log.warning("IOT_WAREHOUSE_ID is not set — SQL queries will fail.")

cfg = Config()  # picks up DATABRICKS_HOST + auth from the Databricks App runtime


@contextmanager
def get_connection() -> Iterator[Any]:
    """One-shot Databricks SQL connection per request (cheap thanks to serverless warehouse)."""
    if not WAREHOUSE_ID:
        raise HTTPException(500, "Warehouse not configured")
    conn = sql.connect(
        server_hostname=cfg.host.replace("https://", ""),
        http_path=f"/sql/1.0/warehouses/{WAREHOUSE_ID}",
        credentials_provider=lambda: cfg.authenticate,
    )
    try:
        yield conn
    finally:
        conn.close()


def _rows_to_dicts(cursor) -> list[dict[str, Any]]:
    cols = [c[0] for c in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]


app = FastAPI(title="IoT Device Tracker")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "table": f"{CATALOG}.{SCHEMA}.{TABLE}",
        "warehouse_configured": bool(WAREHOUSE_ID),
        "default_device_id": DEVICE_ID,
    }


@app.get("/api/devices")
def devices() -> list[dict[str, Any]]:
    sql_text = f"""
        SELECT device_id,
               MAX(event_timestamp) AS last_seen,
               COUNT(*) AS event_count
        FROM {FQN}
        GROUP BY device_id
        ORDER BY last_seen DESC
    """
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute(sql_text)
        return _rows_to_dicts(cur)


@app.get("/api/latest")
def latest(device_id: str | None = Query(None)) -> dict[str, Any]:
    where = f"WHERE device_id = '{_safe(device_id)}'" if device_id else ""
    sql_text = f"""
        SELECT * FROM {FQN}
        {where}
        ORDER BY event_timestamp DESC
        LIMIT 1
    """
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute(sql_text)
        rows = _rows_to_dicts(cur)
        if not rows:
            return {}
        return rows[0]


@app.get("/api/events")
def events(
    minutes: float = Query(10, gt=0, le=1440),
    device_id: str | None = Query(None),
    limit: int = Query(2000, ge=1, le=20000),
) -> list[dict[str, Any]]:
    seconds = int(float(minutes) * 60)
    where = [f"event_timestamp > current_timestamp() - INTERVAL {seconds} SECOND"]
    if device_id:
        where.append(f"device_id = '{_safe(device_id)}'")
    sql_text = f"""
        SELECT event_timestamp, device_id, latitude, longitude, speed, bearing,
               altitude, location_accuracy,
               accel_x, accel_y, accel_z, accel_magnitude,
               gyro_x, gyro_y, gyro_z,
               battery_level, is_charging
        FROM {FQN}
        WHERE {' AND '.join(where)}
        ORDER BY event_timestamp ASC
        LIMIT {int(limit)}
    """
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute(sql_text)
        return _rows_to_dicts(cur)


@app.get("/api/stats")
def stats(minutes: float = Query(60, gt=0, le=1440), device_id: str | None = Query(None)) -> dict[str, Any]:
    seconds = int(float(minutes) * 60)
    where = [f"event_timestamp > current_timestamp() - INTERVAL {seconds} SECOND"]
    if device_id:
        where.append(f"device_id = '{_safe(device_id)}'")
    sql_text = f"""
        SELECT COUNT(*)                                   AS event_count,
               AVG(speed)                                 AS avg_speed,
               MAX(speed)                                 AS max_speed,
               AVG(accel_magnitude)                       AS avg_accel,
               MAX(accel_magnitude)                       AS max_accel,
               MIN(battery_level)                         AS min_battery,
               MAX(battery_level)                         AS max_battery,
               MIN(event_timestamp)                       AS first_event,
               MAX(event_timestamp)                       AS last_event
        FROM {FQN}
        WHERE {' AND '.join(where)}
    """
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute(sql_text)
        rows = _rows_to_dicts(cur)
        return rows[0] if rows else {}


def _safe(s: str) -> str:
    return (s or "").replace("'", "''")


# ---------- Static frontend (single-file React via CDN — no build step) ----------
STATIC_DIR = Path(__file__).parent / "static"

@app.get("/")
def root() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/{path:path}")
def static_files(path: str) -> FileResponse:
    target = STATIC_DIR / path
    if target.is_file():
        return FileResponse(target)
    return FileResponse(STATIC_DIR / "index.html")
