#!/usr/bin/env bash
#
# setup_simulator.sh — installs Python deps and compiles the protobuf schema
# for the IoT device simulator (runs on Mac/Linux, NOT inside Termux).
#
# Usage:
#   cd simulator
#   bash setup_simulator.sh
#
set -euo pipefail

SIM_DIR="$(cd "$(dirname "$0")" && pwd)"
PROTO_DIR="${SIM_DIR}/../proto"
PROTO_FILE="${PROTO_DIR}/iot_event.proto"

echo "===> 1/3 Creating virtualenv (./.venv)"
python3 -m venv "${SIM_DIR}/.venv"
# shellcheck disable=SC1091
source "${SIM_DIR}/.venv/bin/activate"

echo "===> 2/3 Installing Python libs"
pip install --upgrade pip
pip install \
  "databricks-sdk>=0.85.0" \
  "databricks-zerobus-ingest-sdk>=0.2.0" \
  "grpcio>=1.62.0" \
  "grpcio-tools>=1.62.0" \
  "protobuf>=5.26.0"

echo "===> 3/3 Compiling the protobuf schema"
if [[ ! -f "${PROTO_FILE}" ]]; then
  echo "ERROR: ${PROTO_FILE} not found."
  exit 1
fi
python -m grpc_tools.protoc \
  --proto_path="${PROTO_DIR}" \
  --python_out="${SIM_DIR}" \
  "${PROTO_FILE}"
echo "      -> generated ${SIM_DIR}/iot_event_pb2.py"

echo ""
echo "============================================================"
echo "Setup complete. Next:"
echo ""
echo "  1. Copy the device_config.json produced by the Databricks setup"
echo "     notebook into this folder (or pass --config <path>):"
echo "       cp ../iot_device/device_config.json ./device_config.json"
echo ""
echo "  2. Activate the venv and run the simulator with your chosen size:"
echo "       source .venv/bin/activate"
echo "       python simulate_devices.py --count 100 --rate 1.0"
echo ""
echo "  The device count is dynamic. You can:"
echo "    - pass --count N on the CLI"
echo "    - export IOT_DEVICE_COUNT=N before launching"
echo "    - put \"device_count\": N inside device_config.json"
echo "    - resize live: 'export IOT_DEVICE_COUNT=N && kill -USR1 <pid>'"
echo ""
echo "  Try also:  --base-lat -23.5505 --base-lon -46.6333  (Sao Paulo)"
echo "             --base-lat  40.7128 --base-lon -74.0060  (New York)"
echo "============================================================"
