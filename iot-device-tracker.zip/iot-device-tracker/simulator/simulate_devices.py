#!/usr/bin/env python3
"""
simulate_devices.py — pushes fake telemetry for N virtual IoT devices into the
same Delta table via Zerobus. Runs locally (Mac/Linux), reusing the same
device_config.json that a real device uses.

A single Zerobus stream carries all N devices — each record just sets a
different `device_id` (sim-001, sim-002, ...). This is the cheapest way to
scale-test the dashboard.

Device count is fully dynamic:
    - pass --count from the CLI, OR
    - set IOT_DEVICE_COUNT in the environment, OR
    - put "device_count" inside device_config.json

You can also resize on the fly by sending SIGUSR1 with a new IOT_DEVICE_COUNT
exported in the same shell (the next cycle picks the new value up).

Usage:
    cd simulator
    source .venv/bin/activate
    python simulate_devices.py --count 100 --rate 1.0

Common flags:
    --count          Number of virtual devices (default from env/config or 10).
    --rate           Records per second per device (default 1.0).
    --base-lat       Centre latitude of the simulated cluster.
    --base-lon       Centre longitude.
    --radius-km      Spread radius around the centre (default 1.0 km).
    --device-prefix  Prefix for device IDs (default 'sim').
    --duration       Seconds to run (default 0 = forever).
    --config         Path to device_config.json (default ./device_config.json,
                     then ../iot_device/device_config.json).
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import os
import random
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Any

try:
    import iot_event_pb2  # type: ignore
except ImportError:
    sys.stderr.write(
        "ERROR: iot_event_pb2 not found. Run setup_simulator.sh first.\n"
    )
    sys.exit(1)

from zerobus.sdk.shared import RecordType, StreamConfigurationOptions, TableProperties
from zerobus.sdk.sync import ZerobusSdk

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
log = logging.getLogger("sim")


# ---------- One virtual device's state ----------
class VirtualDevice:
    EARTH_R = 6_371_000.0  # metres

    def __init__(self, device_id: str, base_lat: float, base_lon: float, radius_km: float, session_id: str):
        self.device_id = device_id
        self.session_id = session_id
        angle = random.uniform(0, 2 * math.pi)
        dist_m = random.uniform(0, radius_km * 1000.0)
        d_lat = (dist_m * math.cos(angle)) / self.EARTH_R
        d_lon = (dist_m * math.sin(angle)) / (self.EARTH_R * math.cos(math.radians(base_lat)))
        self.lat = base_lat + math.degrees(d_lat)
        self.lon = base_lon + math.degrees(d_lon)
        self.altitude = random.uniform(720.0, 770.0)
        self.heading = random.uniform(0, 2 * math.pi)
        self.speed = random.uniform(0.0, 3.0)
        self._t0 = time.time() + random.uniform(0, 100)
        self.battery = random.uniform(40.0, 95.0)
        self.charging = random.random() < 0.1

    def step(self, dt: float) -> "iot_event_pb2.IotEvent":
        self.heading += random.gauss(0, 0.2)
        self.speed = max(0.0, min(5.0, self.speed + random.gauss(0, 0.2)))

        dist_m = self.speed * dt
        d_lat = (dist_m * math.cos(self.heading)) / self.EARTH_R
        d_lon = (dist_m * math.sin(self.heading)) / (self.EARTH_R * math.cos(math.radians(self.lat)))
        self.lat += math.degrees(d_lat)
        self.lon += math.degrees(d_lon)
        self.altitude += random.gauss(0, 0.05)

        self.battery = max(1.0, min(100.0, self.battery + (0.01 if self.charging else -0.005)))

        t = time.time() - self._t0
        ax = 0.4 * math.sin(2 * t + 0.3) + random.gauss(0, 0.1)
        ay = 0.4 * math.cos(1.7 * t) + random.gauss(0, 0.1)
        az = 9.81 + 0.3 * math.sin(0.9 * t) + random.gauss(0, 0.1)
        gx = 0.05 * math.sin(0.7 * t) + random.gauss(0, 0.02)
        gy = 0.05 * math.cos(0.6 * t) + random.gauss(0, 0.02)
        gz = 0.02 * math.sin(1.3 * t) + random.gauss(0, 0.02)

        ev = iot_event_pb2.IotEvent()
        ev.device_id = self.device_id
        ev.session_id = self.session_id
        ev.event_timestamp = int(time.time() * 1_000_000)
        ev.latitude = self.lat
        ev.longitude = self.lon
        ev.altitude = self.altitude
        ev.speed = self.speed
        ev.bearing = math.degrees(self.heading) % 360.0
        ev.location_accuracy = 5.0
        ev.location_provider = "simulator"
        ev.accel_x, ev.accel_y, ev.accel_z = ax, ay, az
        ev.accel_magnitude = math.sqrt(ax * ax + ay * ay + az * az)
        ev.gyro_x, ev.gyro_y, ev.gyro_z = gx, gy, gz
        ev.orient_azimuth = math.degrees(self.heading) % 360.0
        ev.orient_pitch = random.gauss(0, 5)
        ev.orient_roll = random.gauss(0, 5)
        ev.battery_level = self.battery
        ev.battery_status = "CHARGING" if self.charging else "DISCHARGING"
        ev.battery_temperature = 30.0 + random.gauss(0, 0.5)
        ev.is_charging = self.charging
        return ev


def _resolve_count(args: argparse.Namespace, cfg: dict[str, Any]) -> int:
    """Resolve device count from CLI -> env -> config -> default."""
    if args.count is not None:
        return int(args.count)
    env_val = os.environ.get("IOT_DEVICE_COUNT")
    if env_val:
        return int(env_val)
    if "device_count" in cfg:
        return int(cfg["device_count"])
    return 10


# ---------- Simulator orchestration ----------
class Simulator:
    def __init__(self, cfg: dict[str, Any], args: argparse.Namespace):
        self.cfg = cfg
        self.args = args
        self.session_id = cfg.get("session_id") or f"sim-{int(time.time())}"
        initial_count = _resolve_count(args, cfg)
        self.devices: list[VirtualDevice] = []
        self._resize(initial_count)

        self.dt = 1.0 / max(args.rate, 0.001)
        self.descriptor = iot_event_pb2.IotEvent.DESCRIPTOR
        self.sdk = ZerobusSdk(cfg["zerobus_endpoint"], cfg["workspace_url"])
        self.table_props = TableProperties(cfg["table_fqn"], self.descriptor)
        self.options = StreamConfigurationOptions(record_type=RecordType.PROTOBUF)

        log.info("Opening stream -> %s", cfg["table_fqn"])
        self.stream = self.sdk.create_stream(
            cfg["client_id"], cfg["client_secret"], self.table_props, self.options
        )
        self._stop = threading.Event()
        signal.signal(signal.SIGINT, self._sig_stop)
        signal.signal(signal.SIGTERM, self._sig_stop)
        try:
            signal.signal(signal.SIGUSR1, self._sig_resize)
        except (AttributeError, ValueError):
            pass  # SIGUSR1 not available on Windows

    def _sig_stop(self, *_: Any) -> None:
        log.info("Shutdown requested")
        self._stop.set()

    def _sig_resize(self, *_: Any) -> None:
        try:
            new_count = int(os.environ.get("IOT_DEVICE_COUNT", "0"))
        except ValueError:
            new_count = 0
        if new_count <= 0:
            log.warning("SIGUSR1 received but IOT_DEVICE_COUNT is not a positive int")
            return
        log.info("SIGUSR1: resizing device pool to %d", new_count)
        self._resize(new_count)

    def _resize(self, target: int) -> None:
        current = len(self.devices)
        if target == current:
            return
        if target > current:
            for i in range(current + 1, target + 1):
                self.devices.append(
                    VirtualDevice(
                        device_id=f"{self.args.device_prefix}-{i:03d}",
                        base_lat=self.args.base_lat,
                        base_lon=self.args.base_lon,
                        radius_km=self.args.radius_km,
                        session_id=self.session_id,
                    )
                )
        else:
            del self.devices[target:]
        log.info("Device pool size: %d", len(self.devices))

    def run(self) -> None:
        start = time.time()
        total = 0
        last_log = start

        try:
            while not self._stop.is_set():
                tick = time.time()
                for dev in self.devices:
                    ev = dev.step(self.dt)
                    try:
                        self.stream.ingest_record(ev)
                        total += 1
                    except Exception as e:
                        log.warning("ingest failed for %s: %s", dev.device_id, e)

                now = time.time()
                if now - last_log >= 5.0:
                    elapsed = now - start
                    rps = total / max(elapsed, 1e-6)
                    log.info(
                        "devices=%d total_records=%d elapsed=%.1fs rate=%.1f rec/s",
                        len(self.devices),
                        total,
                        elapsed,
                        rps,
                    )
                    last_log = now

                if self.args.duration and (now - start) >= self.args.duration:
                    log.info("Duration reached, stopping.")
                    break

                spent = time.time() - tick
                sleep_for = self.dt - spent
                if sleep_for > 0:
                    self._stop.wait(timeout=sleep_for)
                elif spent > self.dt * 1.5:
                    log.warning(
                        "Cycle took %.2fs > target %.2fs — drop --count or --rate.",
                        spent,
                        self.dt,
                    )
        finally:
            log.info("Flushing stream (total records: %d) ...", total)
            try:
                self.stream.flush()
            except Exception as e:
                log.warning("flush error: %s", e)
            try:
                self.stream.close()
            except Exception as e:
                log.warning("close error: %s", e)
            log.info("Bye.")


def _resolve_config(path: Path) -> Path:
    if path.is_file():
        return path
    alt = Path(__file__).parent.parent / "iot_device" / "device_config.json"
    if alt.is_file():
        return alt
    raise FileNotFoundError(f"device_config.json not found at {path} or {alt}")


def main() -> int:
    p = argparse.ArgumentParser(description="Simulate N virtual IoT devices writing to the same Delta table.")
    p.add_argument("--count", type=int, default=None,
                   help="Number of virtual devices (overrides env IOT_DEVICE_COUNT and config.device_count)")
    p.add_argument("--rate", type=float, default=1.0, help="Records per second per device")
    p.add_argument("--base-lat", type=float, default=0.0, help="Centre latitude")
    p.add_argument("--base-lon", type=float, default=0.0, help="Centre longitude")
    p.add_argument("--radius-km", type=float, default=1.0, help="Spread radius around the centre")
    p.add_argument("--device-prefix", type=str, default="sim", help="Device-ID prefix")
    p.add_argument("--duration", type=int, default=0, help="Seconds to run (0 = forever)")
    p.add_argument(
        "--config",
        type=Path,
        default=Path(__file__).with_name("device_config.json"),
        help="device_config.json path",
    )
    args = p.parse_args()

    cfg_path = _resolve_config(args.config)
    log.info("Using config %s", cfg_path)
    with open(cfg_path, "r") as f:
        cfg = json.load(f)

    initial = _resolve_count(args, cfg)
    if initial <= 0:
        log.error("Device count must be > 0 (got %d)", initial)
        return 2
    if initial * args.rate > 15_000:
        log.warning(
            "Configured throughput %.0f rec/s exceeds Zerobus per-stream limit (~15000).",
            initial * args.rate,
        )

    Simulator(cfg, args).run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
