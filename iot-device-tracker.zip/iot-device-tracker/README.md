# IoT Device Tracker

End-to-end pipeline: **IoT device → Zerobus → Delta (Unity Catalog) → FastAPI + React**.

Everything is parameterized via widgets/flags — run it in any workspace today and reproduce it elsewhere by changing the values.

**Works on AWS, Azure and GCP.** Nothing is cloud-specific: the setup notebook auto-detects the cloud from the workspace hostname and picks a Zerobus endpoint default; the dropdown widget exposes every supported region across all three clouds.

```
[ IoT device (real or simulated) ]──gRPC──▶ [ Zerobus ]──▶ [ Delta table ]
                                                                ▲
                                                                │ SQL
                                                                │
                                                      [ FastAPI ]──▶ [ React (map + charts) ]
                                                                            └─ Databricks App
```

The reference device implementation is an Android handset running Termux (the schema is generic and works for any device that can speak gRPC + Protobuf). A local simulator lets you spawn N virtual devices on your laptop to load-test the dashboard without buying hardware.

## Project layout

```
iot-device-tracker/
├── proto/iot_event.proto             # Shared schema (source of truth)
├── databricks/01_databricks_setup.py # Widget-driven notebook — creates UC, SP, secret
├── iot_device/
│   ├── device_setup.sh               # Termux setup (installs deps + compiles proto)
│   ├── device_collector.py           # Real-device collector (Termux + termux-api)
│   └── device_config.template.json   # Config template (filled by the notebook)
├── simulator/
│   ├── setup_simulator.sh            # Local virtualenv + protoc
│   └── simulate_devices.py           # Spawn N virtual devices (dynamic count)
├── app/
│   ├── app.yaml                      # Databricks App config (placeholders)
│   ├── requirements.txt
│   ├── main.py                       # FastAPI (/api/... routes)
│   └── static/index.html             # Single-file React (CDN, no build step)
└── deploy_app.sh                     # Optional: local-only deploy script
```

> **Why no npm?** The React frontend is a single `index.html` that pulls React, Leaflet and `htm` from a CDN at runtime. Zero build steps, which means the Databricks notebook can deploy the whole app — frontend included — without anything running on your laptop.

---

## 1. Databricks setup (data + app, all in one notebook)

1. Get the project into the workspace. Easiest way:
   - **Workspace → Add → Git folder**, paste the repo URL. The `app/` folder will sit next to the notebook automatically.
   - Or upload the whole project tree manually so `app/` and `databricks/01_databricks_setup.py` are siblings.
2. Open `databricks/01_databricks_setup.py` and adjust the widgets:
   - `catalog`, `schema`, `table` — where the Delta table will live
   - `sp_display_name` — service principal name for the devices
   - `device_id` — default device identifier
   - `zerobus_endpoint` — leave `auto-detect` or override
   - `rotate_secret` — set to `true` to regenerate the OAuth secret
   - `app_name` — Databricks App name
   - `deploy_app` — `true` (default) to deploy the app right from the notebook
3. Run all cells.
4. Save the **`device_config.json`** that the notebook prints — that's what the device or simulator needs.

> The notebook is fully idempotent: it never tries to create catalogs (only validates they exist), creates the schema/table only when missing, reuses the SP, only rotates the OAuth secret when you ask, and re-applies grants without clobbering existing ACLs. The Databricks App is created on the first run and re-deployed on subsequent runs.

---

## 2a. Run a real device (Android via Termux)

The Zerobus Python SDK ships native Rust extensions that don't compile on Termux's bionic libc. Trick: capture sensors in **native Termux** (where `termux-sensor` exists), forward via JSONL to **proot Debian** (where the SDK installs cleanly on glibc).

### One-time setup

On the Android device:

1. Install **Termux** from **F-Droid** (Play Store version is outdated).
2. Install **Termux:API** from the Play Store. In Android Settings → Apps → Termux:API → Permissions, enable **Location** + **Sensors**.
3. Send `iot.zip` to the Android device (Drive, WhatsApp, email — anything).
4. In Termux:
   ```bash
   pkg install -y unzip
   mkdir -p ~/iot/iot_device && cd ~/iot/iot_device
   unzip -o ~/storage/downloads/iot.zip
   bash device_setup.sh
   ```
   The setup installs Python + proot Debian + the Zerobus SDK inside Debian. ~3–5 min the first time.
5. Drop the `device_config.json` (printed by the notebook) into the **canonical path** the collector reads:
   ```bash
   nano /sdcard/iot/collector/device_config.json
   # paste, Ctrl+O, Ctrl+X
   ```
   ⚠️ Always edit `/sdcard/iot/collector/device_config.json` — never the copy that lives next to the setup script.

### Run (two Termux sessions)

Swipe from the **left edge** of the Termux screen → **New session**.

**Session 1 — native Termux (sensor capture):**
```bash
termux-wake-lock                    # stops Android from killing the script
bash ~/iot/iot_device/native_capture.sh
```
This streams accel/gyro/orientation to `/sdcard/iot/sensors.jsonl`, plus periodic GPS and battery snapshots. Leave it running.

**Session 2 — proot Debian (gRPC sender):**
```bash
proot-distro login debian
cd /sdcard/iot/collector
python3 device_collector.py --jsonl /sdcard/iot/sensors.jsonl
```

You should see:
```
INFO Opening Zerobus stream (JSON) -> catalog.iot.events
INFO Successfully created stream stream_id=...
INFO tailing /sdcard/iot/sensors.jsonl
INFO sent=50 rate=10.0 rec/s |a|=9.82 lat=-23.55 lon=-46.63
```

To keep running with the screen locked:
```bash
nohup python3 device_collector.py --jsonl /sdcard/iot/sensors.jsonl > collector.log 2>&1 &
tail -f collector.log
```

## 2b. Run the simulator (any number of virtual devices)

The simulator spawns N virtual IoT devices and writes them all into the same table through **one Zerobus stream** — the cheapest way to load-test the dashboard.

```bash
cd simulator
bash setup_simulator.sh           # virtualenv + protoc

cp ../iot_device/device_config.json ./device_config.json
source .venv/bin/activate

# Dynamic count: any of these works (CLI wins, then env, then config)
python simulate_devices.py --count 100 --rate 1.0
IOT_DEVICE_COUNT=250 python simulate_devices.py
echo '{"device_count":500, ...}' > device_config.json && python simulate_devices.py

# Spread them around a real-world hotspot:
python simulate_devices.py --count 100 --base-lat -23.5505 --base-lon -46.6333

# Resize live without restarting: re-export and signal the process
export IOT_DEVICE_COUNT=200
kill -USR1 $(pgrep -f simulate_devices.py)
```

Throughput cap to keep in mind: **~15,000 records/s** per Zerobus stream. The simulator warns you if `count × rate` exceeds it.

---

## 3. App deploy

The notebook from Section 1 deploys the app for you (widget `deploy_app=true`). It:
1. Locates `app/` next to the notebook in the workspace
2. Writes a freshly-rendered `app.yaml` with your variables
3. Creates the app (if missing) and runs `apps deploy`
4. Grants the app's service principal `USE_CATALOG`, `USE_SCHEMA`, `SELECT` on the table and `CAN_USE` on the warehouse

If you'd rather deploy locally (or you didn't run the project as a Git folder), `deploy_app.sh` does the same thing from your Mac with the Databricks CLI.

---

## 4. Run it in a different workspace (or a different cloud)

1. Add the repo as a Git folder in the new workspace (or upload the tree).
2. Open `databricks/01_databricks_setup.py`, change the widgets if needed, run all cells. The app redeploys automatically.
3. Update `device_config.json` on the device(s) / simulator with the new values.

Nothing is hardcoded — every target comes from a variable.

### What's cloud-agnostic vs. cloud-specific

| Component                          | Cloud-specific? | Notes                                                                  |
|------------------------------------|-----------------|------------------------------------------------------------------------|
| Device collector (Termux + gRPC)   | No              | Only the `zerobus_endpoint` URL changes per cloud/region.              |
| Simulator                          | No              | Same.                                                                  |
| Service principal + OAuth secret   | No              | Same Databricks SDK call on all clouds.                                |
| Unity Catalog + Delta table        | No              | Same SQL on all clouds.                                                |
| Warehouse grants (`CAN_USE`)       | No              | Same SDK call.                                                         |
| FastAPI + React app                | No              | Uses `databricks-sql-connector` + SDK auth from the App runtime.       |
| `databricks apps deploy`           | No              | Same CLI on all clouds.                                                |
| Zerobus endpoint hostname          | **Yes**         | One default per cloud, override via the widget dropdown.               |

---

## App API

| Endpoint                         | Description                                  |
|----------------------------------|----------------------------------------------|
| `GET /api/health`                | Status + configured table                    |
| `GET /api/devices`               | Devices with `last_seen` + `event_count`     |
| `GET /api/latest?device_id=…`    | Most recent reading                          |
| `GET /api/events?minutes=N&…`    | Events from the last N minutes               |
| `GET /api/stats?minutes=N&…`     | Aggregates (count, avg speed, max accel, …)  |

The frontend polls these routes (configurable: 1s / 2s / 5s / 15s).

---

## Troubleshooting

| Symptom                                                     | Likely cause / fix                                                                                                                                       |
|-------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| `termux-sensor: command not found`                          | Termux:API app missing. Install from Play Store and reopen Termux.                                                                                       |
| Collector has no `latitude` / `longitude`                   | Termux:API lacks Location permission in Android settings.                                                                                                |
| Collector: `dns error` / `Name or service not known`        | The endpoint hostname is wrong. Confirm `device_config.json` at `/sdcard/iot/collector/device_config.json` uses `https://<workspace_id>.zerobus.<region>.gcp.databricks.com` (per-workspace, NOT a generic region URL). |
| Collector: edits to `device_config.json` aren't taking effect | The collector reads from `/sdcard/iot/collector/device_config.json` — make sure you are editing **that** file, not the copy next to `device_setup.sh`. |
| Simulator: cycle time > target                              | Lower `--count` or `--rate`. Multi-stream is out of scope for v1.                                                                                        |
| App: `IOT_WAREHOUSE_ID` not set                             | Re-run the setup notebook (it renders `app.yaml` with the warehouse id).                                                                                 |
| App: `permission denied` on the table                       | Grant SELECT to the **app's** SP (not the device's). The notebook does this automatically; if it didn't, grant it manually in Catalog Explorer.          |
| Notebook: "App source not found"                            | Make sure the `app/` folder is a sibling (or parent) of the notebook in the workspace. Easiest: add the repo as a **Workspace Git folder**.              |
| proot Debian: `apt update` fails with DNS                   | The setup writes `/etc/resolv.conf` and patches `/root/.bashrc`. If you bypassed setup, run inside proot: `echo -e "nameserver 8.8.8.8\\nnameserver 1.1.1.1" > /etc/resolv.conf`. |
| `grpcio` fails to build in Termux        | `pkg install clang make python-dev` before `pip install grpcio`.            |

---

## Local app dev (without Databricks Apps)

```bash
cd app
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export IOT_CATALOG=main IOT_SCHEMA=iot IOT_TABLE=events
export IOT_WAREHOUSE_ID=<warehouse_id>
export DATABRICKS_HOST=https://<workspace>
export DATABRICKS_TOKEN=<your_pat>
uvicorn main:app --reload --port 8000   # full app at http://localhost:8000
```

The frontend is bundled into FastAPI as a static `index.html` — no separate dev server needed.
