#!/usr/bin/env bash
#
# deploy_app.sh — builds the frontend, uploads sources to the workspace and
# creates/updates the Databricks App.
#
# Prerequisites:
#   - databricks CLI configured with a profile authenticated to the target workspace
#   - npm/node installed locally to build the React frontend
#   - export PROFILE=<your_profile>  (or pass --profile)
#
# Usage:
#   ./deploy_app.sh \
#     --profile <profile> \
#     --app-name iot-tracker \
#     --warehouse-id <warehouse_id> \
#     --catalog main --schema iot --table events \
#     --device-id device-01
#
set -euo pipefail

PROFILE="${PROFILE:-DEFAULT}"
APP_NAME="iot-tracker"
CATALOG="main"
SCHEMA="iot"
TABLE="events"
DEVICE_ID="device-01"
WAREHOUSE_ID=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile)        PROFILE="$2"; shift 2 ;;
    --app-name)       APP_NAME="$2"; shift 2 ;;
    --warehouse-id)   WAREHOUSE_ID="$2"; shift 2 ;;
    --catalog)        CATALOG="$2"; shift 2 ;;
    --schema)         SCHEMA="$2"; shift 2 ;;
    --table)          TABLE="$2"; shift 2 ;;
    --device-id)      DEVICE_ID="$2"; shift 2 ;;
    -h|--help)
      grep '^#' "$0" | head -25
      exit 0
      ;;
    *) echo "unknown arg: $1"; exit 2 ;;
  esac
done

if [[ -z "${WAREHOUSE_ID}" ]]; then
  echo "ERROR: --warehouse-id is required (take it from the Databricks setup output)."
  exit 2
fi

ROOT="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="${ROOT}/app"

echo "===> 1/5 Building the React frontend"
cd "${APP_DIR}/frontend"
if [[ ! -d node_modules ]]; then
  npm install
fi
npm run build

echo ""
echo "===> 2/5 Rendering app.yaml with your variables"
cat > "${APP_DIR}/app.yaml" <<YAML
command:
  - "uvicorn"
  - "main:app"
  - "--host"
  - "0.0.0.0"
  - "--port"
  - "8000"

env:
  - name: IOT_CATALOG
    value: "${CATALOG}"
  - name: IOT_SCHEMA
    value: "${SCHEMA}"
  - name: IOT_TABLE
    value: "${TABLE}"
  - name: IOT_DEVICE_ID
    value: "${DEVICE_ID}"
  - name: IOT_WAREHOUSE_ID
    value: "${WAREHOUSE_ID}"

resources:
  - name: iot_warehouse
    description: "SQL warehouse that backs the dashboard queries"
    sql_warehouse:
      id: "${WAREHOUSE_ID}"
      permission: "CAN_USE"
YAML
cat "${APP_DIR}/app.yaml"

echo ""
echo "===> 3/5 Syncing sources to the workspace"
USER_EMAIL=$(databricks current-user me --profile "${PROFILE}" --output json | python3 -c 'import json,sys;print(json.load(sys.stdin)["userName"])')
WS_SRC_DIR="/Users/${USER_EMAIL}/${APP_NAME}"
echo "      target: ${WS_SRC_DIR}"

databricks workspace mkdirs "${WS_SRC_DIR}" --profile "${PROFILE}" || true

databricks sync "${APP_DIR}" "${WS_SRC_DIR}" \
  --profile "${PROFILE}" \
  --full \
  --exclude "frontend/node_modules" \
  --exclude "frontend/src" \
  --exclude "frontend/package*.json" \
  --exclude "frontend/tsconfig*.json" \
  --exclude "frontend/vite.config.ts" \
  --exclude "frontend/index.html" \
  --exclude ".venv"

echo ""
echo "===> 4/5 Creating the app (if missing)"
if ! databricks apps get "${APP_NAME}" --profile "${PROFILE}" >/dev/null 2>&1; then
  databricks apps create "${APP_NAME}" --profile "${PROFILE}"
fi

echo ""
echo "===> 5/5 Deploying the app"
databricks apps deploy "${APP_NAME}" \
  --source-code-path "${WS_SRC_DIR}" \
  --profile "${PROFILE}"

echo ""
echo "============================================================"
APP_URL=$(databricks apps get "${APP_NAME}" --profile "${PROFILE}" --output json | python3 -c 'import json,sys;print(json.load(sys.stdin).get("url",""))')
echo "App URL: ${APP_URL}"
echo ""
echo "IMPORTANT: open the app's Permissions and grant the APP service principal:"
echo "  - USE_CATALOG on ${CATALOG}"
echo "  - USE_SCHEMA  on ${CATALOG}.${SCHEMA}"
echo "  - SELECT      on ${CATALOG}.${SCHEMA}.${TABLE}"
echo "============================================================"
