#!/data/data/com.termux/files/usr/bin/bash
#
# native_capture.sh — runs in **native Termux** (NOT inside proot Debian).
#
# Streams sensors to /sdcard/iot/sensors.jsonl (JSONL: one termux-sensor
# block per line), and periodically refreshes /sdcard/iot/location.json
# and /sdcard/iot/battery.json. The collector (in proot Debian) reads
# those files and forwards everything via Zerobus.
#
# Usage:
#   termux-wake-lock   # keep Android from killing this script
#   bash native_capture.sh
#
# (we intentionally do NOT use `set -e` — background loops handle their own
#  errors so a single failed sensor read never kills the whole script.)

mkdir -p /sdcard/iot

if ! command -v termux-sensor >/dev/null; then
  echo "ERROR: termux-sensor not available. Install the Termux:API app from"
  echo "       the Play Store and grant it Location + Sensors permissions."
  exit 1
fi

# Truncate the stream file at start so the collector doesn't replay old data.
: > /sdcard/iot/sensors.jsonl

cleanup() {
  echo ""
  echo "stopping background loops..."
  kill $(jobs -p) 2>/dev/null || true
  exit 0
}
trap cleanup INT TERM

# Background loop: refresh location every 5s.
# We try GPS first; if that doesn't return a "latitude" field, fall back to
# network. We always overwrite location.json with whatever the latest call
# produced — including error responses. The collector already ignores entries
# without a "latitude" key, so NULL lat/lon propagates honestly when there is
# no fix instead of replaying a stale value.
(
  while true; do
    termux-location -p gps -r last > /sdcard/iot/location.json.tmp 2>/dev/null || true
    if ! grep -q '"latitude"' /sdcard/iot/location.json.tmp 2>/dev/null; then
      termux-location -p network -r last > /sdcard/iot/location.json.tmp 2>/dev/null || true
    fi
    mv /sdcard/iot/location.json.tmp /sdcard/iot/location.json 2>/dev/null || true
    sleep 5
  done
) &

# Background loop: refresh battery every 30s.
(
  while true; do
    if termux-battery-status > /sdcard/iot/battery.json.tmp 2>/dev/null; then
      if [[ -s /sdcard/iot/battery.json.tmp ]]; then
        mv /sdcard/iot/battery.json.tmp /sdcard/iot/battery.json 2>/dev/null || true
      else
        rm -f /sdcard/iot/battery.json.tmp 2>/dev/null || true
      fi
    fi
    sleep 30
  done
) &

echo "============================================================"
echo "Streaming sensors -> /sdcard/iot/sensors.jsonl"
echo "Location          -> /sdcard/iot/location.json (every 5s)"
echo "Battery           -> /sdcard/iot/battery.json (every 30s)"
echo ""
echo "Keep this session running. In another session, start the proot collector."
echo "Ctrl+C to stop."
echo "============================================================"

# Foreground: stream sensors at ~20 Hz (-d 50ms).
# termux-sensor sometimes exits after Termux:API rate-limits or sensor batching
# hiccups — we restart it in a loop so the JSONL keeps growing while the script
# is alive. Each restart appends to the same file (collector tails by offset).
while true; do
  termux-sensor -s "accelerometer,gyroscope,orientation" -d 50 \
    >> /sdcard/iot/sensors.jsonl
  echo "[$(date '+%H:%M:%S')] termux-sensor exited; restarting in 1s..."
  sleep 1
done
