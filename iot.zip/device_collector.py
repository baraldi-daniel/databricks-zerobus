#!/usr/bin/env python3
"""
device_collector.py — IoT device collector for Android.

The Zerobus Python SDK ships native (Rust) extensions that don't compile on
Termux's bionic libc. So this script is meant to run inside **proot Debian**
(glibc, where the SDK pip-installs cleanly), while sensor capture happens in
a parallel **native Termux** session and shares data via files in /sdcard/iot/.

Run modes
---------
1) Real Android (recommended): two Termux sessions.

   Session 1 — native Termux (sensors):
       bash native_capture.sh                # uses termux-sensor + termux-location

   Session 2 — proot Debian (gRPC sender):
       proot-distro login debian
       python3 device_collector.py --jsonl /sdcard/iot/sensors.jsonl

2) Synthetic data (no real sensors, just sine waves with noise) — handy
   to test the pipeline before you have permissions sorted:
       python3 device_collector.py --synthetic
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import random
import signal
import sys
import time
from pathlib import Path
from typing import Any, Iterator

from zerobus.sdk.shared import RecordType, StreamConfigurationOptions, TableProperties
from zerobus.sdk.sync import ZerobusSdk

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("collector")

DEFAULT_LOCATION_FILE = Path("/sdcard/iot/location.json")
DEFAULT_BATTERY_FILE = Path("/sdcard/iot/battery.json")


# ---------- JSONL tailing (incremental JSON parse) ----------
def tail_jsonl(filepath: Path) -> Iterator[dict[str, Any]]:
    decoder = json.JSONDecoder()
    log.info("tailing %s", filepath)
    while not filepath.exists():
        log.info("waiting for %s to appear ...", filepath)
        time.sleep(1.0)
    f = open(filepath, "r")
    f.seek(0, 2)
    buf = ""
    while True:
        chunk = f.read()
        if not chunk:
            time.sleep(0.03)
            continue
        buf += chunk
        idx = 0
        while idx < len(buf):
            while idx < len(buf) and buf[idx].isspace():
                idx += 1
            if idx >= len(buf):
                break
            try:
                obj, end = decoder.raw_decode(buf, idx)
            except json.JSONDecodeError:
                break
            idx = end
            yield obj
        buf = buf[idx:]


def parse_sensor_block(obj: dict[str, Any]) -> dict[str, list[float] | None]:
    """Parse a single termux-sensor output block into accel/gyro/orient."""
    out: dict[str, list[float] | None] = {"accel": None, "gyro": None, "orient": None}
    for key, val in obj.items():
        kl = key.lower()
        values = val.get("values") if isinstance(val, dict) else val
        if not isinstance(values, list) or len(values) < 3:
            continue
        if "linear" in kl:  # skip "linear acceleration"
            continue
        if "accelerometer" in kl or kl.endswith("accel"):
            out["accel"] = [float(values[0]), float(values[1]), float(values[2])]
        elif "gyroscope" in kl or kl.endswith("gyro"):
            out["gyro"] = [float(values[0]), float(values[1]), float(values[2])]
        elif "orientation" in kl or kl.endswith("orient"):
            out["orient"] = [float(values[0]), float(values[1]), float(values[2])]
    return out


def read_side_file(p: Path) -> dict[str, Any]:
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


# ---------- Outlier filter ----------
# termux-sensor occasionally emits a spurious sample with extreme values when
# it restarts or batches. We keep the previous good sample and drop any new
# sample where any axis differs by more than ACCEL_JUMP_LIMIT (m/s^2) or
# GYRO_JUMP_LIMIT (rad/s). This isn't a low-pass filter — it ONLY rejects
# the obvious spikes; normal motion easily stays inside the bands.
ACCEL_JUMP_LIMIT = 8.0   # ~0.8g delta between consecutive samples
GYRO_JUMP_LIMIT = 4.0    # ~4 rad/s delta between consecutive samples

class OutlierGuard:
    def __init__(self):
        self.prev_accel: list[float] | None = None
        self.prev_gyro: list[float] | None = None

    @staticmethod
    def _too_far(prev: list[float], curr: list[float], limit: float) -> bool:
        return any(abs(curr[i] - prev[i]) > limit for i in range(3))

    def check(self, sensors: dict[str, list[float] | None]) -> bool:
        """Return True to keep the sample, False to skip it."""
        a, g = sensors.get("accel"), sensors.get("gyro")
        if a and self.prev_accel and self._too_far(self.prev_accel, a, ACCEL_JUMP_LIMIT):
            return False
        if g and self.prev_gyro and self._too_far(self.prev_gyro, g, GYRO_JUMP_LIMIT):
            return False
        if a:
            self.prev_accel = a
        if g:
            self.prev_gyro = g
        return True


# ---------- Event builder ----------
def build_event(
    device_id: str,
    session_id: str,
    sensors: dict[str, list[float] | None],
    location: dict[str, Any],
    battery: dict[str, Any],
) -> dict[str, Any]:
    ev: dict[str, Any] = {
        "device_id": device_id,
        "session_id": session_id,
        "event_timestamp": int(time.time() * 1_000_000),  # micros since epoch
    }

    a = sensors.get("accel")
    if a:
        ev["accel_x"], ev["accel_y"], ev["accel_z"] = a[0], a[1], a[2]
        ev["accel_magnitude"] = math.sqrt(a[0] ** 2 + a[1] ** 2 + a[2] ** 2)
    g = sensors.get("gyro")
    if g:
        ev["gyro_x"], ev["gyro_y"], ev["gyro_z"] = g[0], g[1], g[2]
    o = sensors.get("orient")
    if o:
        ev["orient_azimuth"], ev["orient_pitch"], ev["orient_roll"] = o[0], o[1], o[2]

    if "latitude" in location:
        ev["latitude"] = float(location["latitude"])
    if "longitude" in location:
        ev["longitude"] = float(location["longitude"])
    if "altitude" in location:
        ev["altitude"] = float(location["altitude"])
    if "speed" in location:
        ev["speed"] = float(location["speed"])
    if "bearing" in location:
        ev["bearing"] = float(location["bearing"])
    if "accuracy" in location:
        ev["location_accuracy"] = float(location["accuracy"])
    if "provider" in location:
        ev["location_provider"] = str(location["provider"])

    if "percentage" in battery:
        ev["battery_level"] = float(battery["percentage"])
    if "status" in battery:
        ev["battery_status"] = str(battery["status"])
    if "temperature" in battery:
        ev["battery_temperature"] = float(battery["temperature"])
    if battery:
        ev["is_charging"] = battery.get("plugged", "UNPLUGGED") != "UNPLUGGED"

    return ev


def synthetic_sample(t: float) -> dict[str, list[float] | None]:
    """Sine waves with noise — useful before sensor permissions are sorted."""
    return {
        "accel": [
            math.sin(t * 0.3) * 0.5 + random.gauss(0, 0.05),
            9.8 + math.sin(t * 0.7) * 0.5 + random.gauss(0, 0.05),
            math.cos(t * 0.5) * 0.3 + random.gauss(0, 0.05),
        ],
        "gyro": [
            math.sin(t * 0.2) * 0.05 + random.gauss(0, 0.01),
            math.cos(t * 0.4) * 0.05 + random.gauss(0, 0.01),
            math.sin(t * 0.6) * 0.02 + random.gauss(0, 0.01),
        ],
        "orient": [(t * 12) % 360, math.sin(t * 0.4) * 30, math.cos(t * 0.6) * 15],
    }


# ---------- Main ----------
def main() -> int:
    p = argparse.ArgumentParser(description="Android IoT collector (Zerobus, runs inside proot Debian)")
    p.add_argument("--config", type=Path, default=Path(__file__).with_name("device_config.json"))
    p.add_argument("--jsonl", type=Path, help="Path to termux-sensor JSONL stream (e.g. /sdcard/iot/sensors.jsonl)")
    p.add_argument("--synthetic", action="store_true", help="Skip sensors, send synthetic samples")
    p.add_argument("--location-file", type=Path, default=DEFAULT_LOCATION_FILE)
    p.add_argument("--battery-file", type=Path, default=DEFAULT_BATTERY_FILE)
    p.add_argument("--rate", type=float, default=10.0, help="Max records per second (default 10)")
    args = p.parse_args()

    if not args.config.is_file():
        log.error("Config %s not found.", args.config)
        return 2
    if not args.jsonl and not args.synthetic:
        log.error("Pass either --jsonl /sdcard/iot/sensors.jsonl  or  --synthetic")
        return 2

    cfg = json.loads(args.config.read_text())
    device_id = cfg["device_id"]
    session_id = cfg.get("session_id") or f"session-{int(time.time())}"
    interval = 1.0 / max(args.rate, 0.01)

    log.info("Opening Zerobus stream (JSON) -> %s", cfg["table_fqn"])
    sdk = ZerobusSdk(cfg["zerobus_endpoint"], cfg["workspace_url"])
    stream = sdk.create_stream(
        cfg["client_id"], cfg["client_secret"],
        TableProperties(cfg["table_fqn"]),
        StreamConfigurationOptions(record_type=RecordType.JSON),
    )

    stop = {"flag": False}

    def _stop(*_): stop["flag"] = True
    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)

    last_send = 0.0
    sent = 0
    t0 = time.time()
    next_log = t0 + 5

    guard = OutlierGuard()
    dropped = 0
    try:
        if args.jsonl:
            for block in tail_jsonl(args.jsonl):
                if stop["flag"]:
                    break
                now = time.time()
                if now - last_send < interval:
                    continue
                last_send = now
                sensors = parse_sensor_block(block)
                if not guard.check(sensors):
                    dropped += 1
                    continue
                location = read_side_file(args.location_file)
                battery = read_side_file(args.battery_file)
                ev = build_event(device_id, session_id, sensors, location, battery)
                stream.ingest_record_nowait(ev)
                sent += 1
                if now > next_log:
                    elapsed = now - t0
                    log.info("sent=%d dropped=%d rate=%.1f rec/s  |a|=%.2f  lat=%s lon=%s",
                             sent, dropped, sent / elapsed,
                             ev.get("accel_magnitude", 0.0),
                             ev.get("latitude"), ev.get("longitude"))
                    next_log = now + 5
        else:
            while not stop["flag"]:
                tick = time.time()
                sensors = synthetic_sample(tick - t0)
                location = read_side_file(args.location_file)
                battery = read_side_file(args.battery_file)
                ev = build_event(device_id, session_id, sensors, location, battery)
                stream.ingest_record_nowait(ev)
                sent += 1
                now = time.time()
                if now > next_log:
                    log.info("sent=%d rate=%.1f rec/s", sent, sent / (now - t0))
                    next_log = now + 5
                rest = interval - (now - tick)
                if rest > 0:
                    time.sleep(rest)
    finally:
        log.info("Flushing stream (sent=%d) ...", sent)
        try:
            stream.flush()
        except Exception as e:
            log.warning("flush error: %s", e)
        try:
            stream.close()
        except Exception as e:
            log.warning("close error: %s", e)

    return 0


if __name__ == "__main__":
    sys.exit(main())
