#!/data/data/com.termux/files/usr/bin/bash
#
# device_setup.sh — one-shot setup for the IoT device on Android Termux.
#
# Why so much: the Zerobus Python SDK ships native (Rust) extensions that
# DON'T compile on Termux's bionic libc. So we install proot Debian (glibc)
# inside Termux, install the SDK in there, and run the collector from
# inside proot. Sensor capture stays in native Termux (where termux-sensor
# lives) and writes JSONL to /sdcard/iot/, which the collector tails.
#
# This script installs both halves automatically (native + inside proot).
#
# After it finishes, the canonical paths on the device are:
#   /sdcard/iot/collector/device_collector.py
#   /sdcard/iot/collector/device_config.json   ← ALWAYS edit this one
#   /sdcard/iot/sensors.jsonl                  ← written by native session
#   /sdcard/iot/location.json                  ← written by native session
#   /sdcard/iot/battery.json                   ← written by native session
#
# Usage (Termux native, NOT proot):
#   pkg install -y unzip
#   mkdir -p ~/iot/iot_device && cd ~/iot/iot_device
#   unzip -o ~/storage/downloads/iot.zip
#   bash device_setup.sh
#
set -euo pipefail

DEVICE_DIR="$(cd "$(dirname "$0")" && pwd)"
COLLECTOR_DIR="/sdcard/iot/collector"

echo "===> 1/4 Native Termux: base packages + proot Debian"
yes | pkg update >/dev/null 2>&1 || true
pkg install -y python termux-api proot-distro curl

# Allow access to /sdcard (used as the bridge between sessions)
if [[ ! -d ~/storage ]]; then
  echo "  running termux-setup-storage — accept the Android permission dialog"
  termux-setup-storage
fi
mkdir -p /sdcard/iot "${COLLECTOR_DIR}"

# Install Debian (idempotent — succeeds if already present)
if proot-distro list 2>/dev/null | grep -q debian; then
  echo "  proot Debian already installed"
else
  echo "  installing proot Debian (this can take ~3-5 minutes)"
  proot-distro install debian
fi

echo ""
echo "===> 2/4 Termux:API companion app"
echo "      Make sure the 'Termux:API' app is installed (from the Play Store)"
echo "      and granted Location + Sensors permissions."
read -r -p "      [Enter to continue once done] " _

echo ""
echo "===> 3/4 Inside proot Debian: install the Zerobus Python SDK"
# Copy the collector into the canonical location accessible from BOTH the
# native session and proot Debian (proot mounts /sdcard automatically).
cp "${DEVICE_DIR}/device_collector.py" "${COLLECTOR_DIR}/"

# If the user already dropped a device_config.json next to the setup script,
# copy it once. After this, the SINGLE source of truth is the file in
# ${COLLECTOR_DIR}. The user should edit that one.
if [[ -f "${DEVICE_DIR}/device_config.json" && ! -f "${COLLECTOR_DIR}/device_config.json" ]]; then
  cp "${DEVICE_DIR}/device_config.json" "${COLLECTOR_DIR}/"
  echo "  copied initial device_config.json to ${COLLECTOR_DIR}/"
fi

proot-distro login debian -- bash -c '
set -euo pipefail
# Fix DNS — proot Debian comes with an empty /etc/resolv.conf so apt fails
# without these nameservers.
cat > /etc/resolv.conf <<EOF
nameserver 8.8.8.8
nameserver 1.1.1.1
EOF
apt update -y >/dev/null
apt install -y python3 python3-pip >/dev/null
pip install --break-system-packages --quiet \
  "databricks-sdk>=0.85.0" \
  "databricks-zerobus-ingest-sdk>=0.2.0"
python3 -c "from zerobus.sdk.sync import ZerobusSdk; print(\"Zerobus SDK OK\")"
'

# Make resolv.conf persistent across logins (proot wipes it on each entry).
# Append to /root/.bashrc inside Debian so every interactive shell restores it.
proot-distro login debian -- bash -c '
if ! grep -q "Restore DNS" /root/.bashrc 2>/dev/null; then
  cat >> /root/.bashrc <<EOF

# Restore DNS on each login (proot wipes /etc/resolv.conf on entry)
cat > /etc/resolv.conf <<INNER
nameserver 8.8.8.8
nameserver 1.1.1.1
INNER
EOF
fi
'

echo ""
echo "===> 4/4 Done."
echo ""
echo "============================================================"
echo "Setup complete. Two Termux sessions are needed to run:"
echo "(swipe from the LEFT EDGE of the Termux screen -> New session)"
echo ""
echo "  Session 1 (native Termux) — sensor capture:"
echo "      termux-wake-lock"
echo "      bash ${DEVICE_DIR}/native_capture.sh"
echo "      (leave it running)"
echo ""
echo "  Session 2 (proot Debian) — gRPC sender to Zerobus:"
echo "      proot-distro login debian"
echo "      cd ${COLLECTOR_DIR}"
echo "      python3 device_collector.py --jsonl /sdcard/iot/sensors.jsonl"
echo ""
echo "  ⚠️  If you need to edit the config, ALWAYS edit:"
echo "      ${COLLECTOR_DIR}/device_config.json"
echo "      (do NOT edit ${DEVICE_DIR}/device_config.json — that path is unused)"
echo "============================================================"
